<?php
// Nothing to clean up in MVP (no options stored).
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}
